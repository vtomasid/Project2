import java.util.Scanner;

/**
 * This class holds instances of Patient and Procedure class.
 */

public class PatientDriverApp {
	
	

	/*
	 * Class: CMSC203 
	 * Instructor:Gary Thai
	 * Description: This class contains an instance of the Patient class, and three
	 * instances from the Procedure class.
	 * Due: 10/04/2024
	 * Platform/compiler:Eclipse
	 * I pledge that I have completed the programming 
	 * assignment independently. I have not copied the code 
	 * from a student or any source. I have not given my code 
	 * to any student.
	   Print your Name here: _Victoria Moody_______
	*/
    public static void main(String[] args) {
    	
    //Create Scanner to allow user input
    	Scanner scanner = new Scanner(System.in);
    	
    	// Collecting patient data from the user
        System.out.println("Enter patient's first name:");
        String firstName = scanner.nextLine();
        
        System.out.println("Enter patient's middle name:");
        String middleName = scanner.nextLine();
        
        System.out.println("Enter patient's last name:");
        String lastName = scanner.nextLine();
        
        System.out.println("Enter street address:");
        String streetAddress = scanner.nextLine();
        
        System.out.println("Enter city:");
        String city = scanner.nextLine();
        
        System.out.println("Enter state:");
        String state = scanner.nextLine();
        
        System.out.println("Enter ZIP code:");
        String zip = scanner.nextLine();
        
        System.out.println("Enter phone number:");
        String phoneNumber = scanner.nextLine();
        
        System.out.println("Enter emergency contact name:");
        String emergencyContact = scanner.nextLine();
        
        System.out.println("Enter emergency contact phone number:");
        String emergencyPNumber = scanner.nextLine();
    
     // Creating an instance of Patient
    Patient patient = new Patient(firstName, middleName, lastName, 
    		streetAddress, city, state, zip, phoneNumber,
    		emergencyContact, emergencyPNumber);
    
    // Display patient details using the custom method
   displayPatient(patient);

    // Creating instances of Procedure using different constructors
    Procedure procedure1 = new Procedure("Biopsy", "06/12/2024", "Dr. Son", 1500.00);
    Procedure procedure2 = new Procedure("MRI", "07/10/2024"); // Only name and date
    Procedure procedure3 = new Procedure(); // No-arg constructor
    
    // Setting values for procedure3
    procedure3.setProcedureName("Endoscopy");
    procedure3.setProcedureDate("08/01/2024");
    procedure3.setPractitionerName("Dr. Moody");
    procedure3.setCharges(-500.00);
    
    // Display procedure details
    System.out.println("\nProcedure Details:");
    System.out.println(procedure1);
    System.out.println("\n" + procedure2);
    System.out.println("\n" + procedure3);
    
     // Calculate total charges
    double totalCharges = calculateTotalCharges(procedure1, procedure2, procedure3);
    
    // Display total charges
    System.out.printf("\nTotal Charges: $%.2f%n", totalCharges);
    
    System.out.println("\nThe program was developed by a Student: Victoria Moody, 10/04/2024");
    // Close the scanner
    scanner.close();
}
    /**
     * This method takes an object as argument and display patient's info
     * @param patient
     */
    //method that given a patient object displays the patient's information
    public static void displayPatient(Patient patient)
    {
    	 System.out.println("\nPatient Details:");
    	    System.out.println(patient);
    }
    /**
     * This method takes a procedure object as an argument and display its information
     * @param proc
     */
 // Method to display procedure information
    public static void displayProcedure(Procedure proc)
    {
    	System.out.println(proc);
    }
    /**
     * This method takes three procedures as arguments and displays the total cost of all three
     * @param proc1
     * @param proc2
     * @param proc3
     * @return
     */
 // Method to calculate total charges of three procedures
    public static double calculateTotalCharges(Procedure procedure1, Procedure procedure2, 
    		Procedure procedure3) {
        return procedure1.getCharges() + procedure2.getCharges() + procedure3.getCharges();
       
       
}
}

    


