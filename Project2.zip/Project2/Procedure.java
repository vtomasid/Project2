/**
 * This class is a blueprint for procedure information
 */
public class Procedure {

	/*
	 * Class: CMSC203 
	 * Instructor:Gary Thai
	 * Description: This class is a blueprint for the procedure's info.
	 * Due: 10/04/2024
	 * Platform/compiler:Eclipse
	 * I pledge that I have completed the programming 
	 * assignment independently. I have not copied the code 
	 * from a student or any source. I have not given my code 
	 * to any student.
	   Print your Name here: _Victoria Moody_______
	*/
	
	private String procedureName;
	private String procedureDate;
	private String practitionerName;
	private double charges;
	
	// No-argument constructor
    public Procedure() {
        this.procedureName = "";
        this.procedureDate = "";
        this.practitionerName = "";
        this.charges = 0.0;
    }
    // Parameterized constructor for procedure name and date only
    public Procedure(String procedureName, String procedureDate) {
        this.procedureName = procedureName;
        this.procedureDate = procedureDate;
        this.practitionerName = "";
        this.charges = 0.0;
    }

    // Parameterized constructor for all attributes
    public Procedure(String procedureName, String procedureDate, String practitionerName, double charges) {
        this.procedureName = procedureName;
        this.procedureDate = procedureDate;
        this.practitionerName = practitionerName;
        this.charges = charges;
    }
    // Getters
    public String getProcedureName() {
        return procedureName;
    }

    public String getProcedureDate() {
        return procedureDate;
    }

    public String getPractitionerName() {
        return practitionerName;
    }

    public double getCharges() {
        return charges;
    }

    // Setters
    public void setProcedureName(String procedureName) {
        this.procedureName = procedureName;
    }

    public void setProcedureDate(String procedureDate) {
        this.procedureDate = procedureDate;
    }

    public void setPractitionerName(String practitionerName) {
        this.practitionerName = practitionerName;
    }

    public void setCharges(double charges) {
    	if (charges < 0) {
            throw new IllegalArgumentException("Charges must be a positive value.");
        }
        this.charges = charges;
    }
   

    // toString method
    @Override
    public String toString() {
        return "Procedure Name: " + procedureName + "\n" +
               "Date of Procedure: " + procedureDate + "\n" +
               "Practitioner: " + practitionerName + "\n" +
               "Charges: $" + charges;
    }
}
