/**
 * this class is a blueprint for patient's information
 */
public class Patient {
	
	/*
	 * Class: CMSC203 
	 * Instructor:Gary Thai
	 * Description: This class is a blueprint for the patient's info.
	 * Due: 10/04/2024
	 * Platform/compiler:Eclipse
	 * I pledge that I have completed the programming 
	 * assignment independently. I have not copied the code 
	 * from a student or any source. I have not given my code 
	 * to any student.
	   Print your Name here: _Victoria Moody_______
	*/
	
	//FIELDS:
	private String firstName, middleName, lastName;
	private String streetAddress, city, state, zip;
	private String phoneNumber;
	private String emergencyContact, emergencyPNumber;
	
	//no-arg Constructor
	public Patient() 
	{
		this.firstName = "";
        this.middleName = "";
        this.lastName = "";
        this.streetAddress = "";
        this.city = "";
        this.state = "";
        this.zip = "";
        this.phoneNumber = "";
        this.emergencyContact = "";
        this.emergencyPNumber = "";
		
	}
	
	//Parametrized constructor that initializes first, middle, and last name
	public Patient(String firstName, String middleName, String lastName)
	{
		this.firstName = firstName;
        this.middleName = middleName;
        this.lastName = lastName;
        this.streetAddress = "";
        this.city = "";
        this.state = "";
        this.zip = "";
        this.phoneNumber = "";
        this.emergencyContact = "";
        this.emergencyPNumber = "";
	}
	//Parametrized constructor that initializes all attributes
	public Patient(String firstName, String middleName, String lastName, String streetAddress, String city,
			String state, String zip, String phoneNumber, String emergencyContact, String emergencyPNumber) {
		 this.firstName = firstName;
	        this.middleName = middleName;
	        this.lastName = lastName;
	        this.streetAddress = streetAddress;
	        this.city = city;
	        this.state = state;
	        this.zip = zip;
	        this.phoneNumber = phoneNumber;
	        this.emergencyContact = emergencyContact;
	        this.emergencyPNumber = emergencyPNumber;
	}
	 // Getters 
    public String getFirstName() {
        return firstName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getStreetAddress() {
        return streetAddress;
    }

    public String getCity() {
        return city;
    }

    public String getState() {
        return state;
    }

    public String getZipCode() {
        return zip;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getEmergencyContactName() {
        return emergencyContact;
    }

    public String getEmergencyContactPhone() {
        return emergencyPNumber;
    }
	//Setters
    public void setFirstName(String firstName) {
    	 if (firstName == null || firstName.trim().isEmpty()) {
             throw new IllegalArgumentException("First name cannot be null or empty.");
         }
        this.firstName = firstName;
    }

    public void setMiddleName(String middleName) {
    	 if (middleName == null || middleName.trim().isEmpty()) {
             throw new IllegalArgumentException("Middle name cannot be null or empty.");
         }
        this.middleName = middleName;
    }

    public void setLastName(String lastName) {
    	 if (lastName == null || lastName.trim().isEmpty()) {
             throw new IllegalArgumentException("Last name cannot be null or empty.");
         }
        this.lastName = lastName;
    }

    public void setStreetAddress(String streetAddress) {
        this.streetAddress = streetAddress;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public void setState(String state) {
        this.state = state;
    }

    public void setZipCode(String zip) {
        this.zip = zip;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public void setEmergencyName(String emergencyContact) {
        this.emergencyContact = emergencyContact;
    }

    public void setEmergencyContactPhone(String emergencyPNumber) {
        this.emergencyPNumber = emergencyPNumber;
    }

    /**
     * This method concatenates first,middle,and last name and returns these values separated by a space
     * @param firstName
     * @param middleName
     * @param lastName
     * @return return firstName + " "+middleName+" "+lastName+".";
     */
    //method that returns a String with the concatenation of first, middle, and last name
    public String buildFullName(String firstName, String middleName, String lastName) {
    	
    	return firstName + " "+middleName+" "+lastName+".";
    }
    /**
     * This method concatenate streetAddress, city, state, and zip values and displays them separated with
     * a space
     * @param streetAddress
     * @param city
     * @param state
     * @param zip
     * @return streetAddress+" "+city+" "+state+" "+zip;
     */
    //method that returns a String with street address, city, state, and zip.
    public String buildAddress(String streetAddress, String city, String state, String zip) {
    	
    	return streetAddress+" "+city+" "+state+" "+zip;
    }
    /**
     * This method concatenates the emergency's contact name and phone number and displays it separated 
     * by a space
     * @param emergencyContact
     * @param emergencyPNumber
     * @return emergencyContact+" "+emergencyPNumber;
     */
    // method that returns a String with emergency's contact name and phone number
    public String buildEmergencyContact(String emergencyContact, String emergencyPNumber)
    {
    	return emergencyContact+" "+emergencyPNumber;
    }
  
    //toString method
    public String toString() 
    {
        return "Name: " + buildFullName(firstName,middleName,lastName) + "\n" +
               "Address: "+buildAddress(streetAddress, city, state, zip) + "\n" +
               "Phone Number: " + phoneNumber + "\n" +
               "EmergencyContact: "+buildEmergencyContact(emergencyContact,emergencyPNumber);
    }
    
    
}
